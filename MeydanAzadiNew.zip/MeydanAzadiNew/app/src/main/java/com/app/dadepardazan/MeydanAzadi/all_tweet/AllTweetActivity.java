package com.app.dadepardazan.MeydanAzadi.all_tweet;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.app.dadepardazan.MeydanAzadi.MainActivity;
import com.app.dadepardazan.MeydanAzadi.R;
import com.app.dadepardazan.MeydanAzadi.show_tweet.ShowTweetActivity;
import com.app.dadepardazan.MeydanAzadi.view_pager.post.ActiviteAndShowTweeetActivity;
import com.app.dadepardazan.MeydanAzadi.view_pager.profile.ProfileAndShowToitActivity;
import com.bumptech.glide.request.RequestOptions;
import com.glide.slider.library.SliderLayout;
import com.glide.slider.library.animations.DescriptionAnimation;
import com.glide.slider.library.slidertypes.BaseSliderView;
import com.glide.slider.library.slidertypes.DefaultSliderView;
import com.glide.slider.library.tricks.ViewPagerEx;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.squareup.picasso.Picasso;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class AllTweetActivity extends MainActivity {
    public static final int RESULT_DATA_SHOW_CHANGE = 468;
    public static final int RESULT_DATA_USER_CHANGE = 458;

    TweetAdapter adapter;
    int last_ad_id = 0;
    TextView not_found;
    RecyclerView recyclerView;
    String str_id_post_like = "";
    JSONArray ad_list;
    String str_android_id = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout content_frame;
        content_frame = (FrameLayout) findViewById(R.id.content_frame);
        getLayoutInflater().inflate(R.layout.activity_all_tweet, content_frame);
        TextView toolbar_title = (TextView) findViewById(R.id.toolbar_title);
        toolbar_title.setText("میدان آزادی");
        toolbar_title.setVisibility(View.VISIBLE);
        BottomNavigationView.getMenu().findItem(R.id.navigation_home).setChecked(true);
        str_android_id = Settings.Secure.getString(this.getContentResolver(), Settings.Secure.ANDROID_ID);

        final SwipeRefreshLayout swipe = (SwipeRefreshLayout) findViewById(R.id.swipe_cnontainer);
        swipe.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                not_found.setVisibility(View.GONE);
                last_ad_id = 0;
                adapter.clear_list();
                new get_list_tweet().execute();
                swipe.setRefreshing(false);


            }
        });

        not_found = (TextView) findViewById(R.id.not_found);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerview);
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager lm = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(lm);


        final ArrayList<JSONObject> data_list = new ArrayList<JSONObject>();

        adapter = new TweetAdapter(getApplicationContext(), data_list) {
            @Override
            public void load_more() {
                new get_list_tweet().execute();
            }
        };
        recyclerView.setAdapter(adapter);
        try {
            String b = "hi";
            String a = new get_list_tweet().execute(b).get();
            //Toast.makeText(this, a, Toast.LENGTH_SHORT).show();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        FloatingActionButton fb_test = findViewById(R.id.fb_test);
        fb_test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new SweetAlertDialog(AllTweetActivity.this, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("ایا مطمئنید?")
                        .setContentText("این فایل دیگر قابل بازیانی نیست!")
                        .setConfirmText("بله پاکش کن!")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog.dismissWithAnimation();
                                new SweetAlertDialog(AllTweetActivity.this, SweetAlertDialog.SUCCESS_TYPE)
                                        .setTitleText("Good job!")
                                        .setContentText("You clicked the button!")
                                        .show();
                            }
                        })
                        .show();
//                new KAlertDialog(AllTweetActivity.this, KAlertDialog.ERROR_TYPE)
//                        .setTitleText("Are you sure?")
//                        .setContentText("Won't be able to recover this file!")
//
//                        .setCancelText("خیر")
//                        .setConfirmText("بله")
//                        .confirmButtonColor(R.color.colorPrimary) // you can change the color of confirm button
//                        .cancelButtonColor(R.color.colorAccent) // you can change the color of cancel button
//                        .showCancelButton(true)
//                        .setCancelClickListener(new KAlertDialog.KAlertClickListener() {
//                            @Override
//                            public void onClick(KAlertDialog sDialog) {
//                                sDialog.cancel();
//                            }
//                        })
//                        .show();


            }
        });

    }

    public void dialog_retweet(final int pos, final JSONObject jsonObject) {
        AlertDialog.Builder builder = new AlertDialog.Builder(AllTweetActivity.this, R.style.DialogeTheme);
        builder.setTitle("ایا می خواهید این پست را ریتویت کنید");
        //builder.setIcon(R.drawable.ic_action_retweet);
        builder.setMessage("با کلید بر روی تایید این پست در صفحه شخصی شما به صورت ریتویت نمایش داده می شود");
        builder.setPositiveButton("تایید", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                final JSONObject get_ad_list = new JSONObject();
                mcrypt = new MainActivity.MCrypt();
                try {

                    get_ad_list.put("command", mcrypt.bytesToHex(mcrypt.encrypt("insert_post")));
                    //get_coment_list.put("category_filter", settings.getInt("category_filter", 0));
                    get_ad_list.put("user_id", mcrypt.bytesToHex(mcrypt.encrypt(String.valueOf(settings.getInt("user_id", 0)))));
                    get_ad_list.put("text", mcrypt.bytesToHex(mcrypt.encrypt(Base64.encodeToString(jsonObject.getString("text").getBytes("UTF-8"), Base64.DEFAULT))));
                    get_ad_list.put("android_id", mcrypt.bytesToHex(mcrypt.encrypt(str_android_id)));
                    get_ad_list.put("repost_id", mcrypt.bytesToHex(mcrypt.encrypt(jsonObject.getString("id_post"))));
                    // get_ad_list.put("repost_id", mcrypt.bytesToHex(mcrypt.encrypt(str_repost_id)));


                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (new send_retweet().execute(get_ad_list).equals("ok")) {
                    Toast.makeText(AllTweetActivity.this, "اطلاعات شما با موفقیت ثبت شد", Toast.LENGTH_SHORT).show();
                    new get_list_tweet().execute();

                    setResult(RESULT_OK);
                }


            }
        });
        builder.setNegativeButton("لغو", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });


        AlertDialog dialog = builder.create();
        //baray zamani k mikhahim dialog bejoz click roy butten az bin naravad
        dialog.setCancelable(true);
        dialog.show();


    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (resultCode == RESULT_OK) {
            new get_list_tweet().execute();
        }
        if (requestCode == RESULT_DATA_SHOW_CHANGE & resultCode == RESULT_OK) {
            try {
                JSONObject job = new JSONObject(data.getStringExtra("ad"));
                adapter.update_item(Integer.parseInt(getIntent().getStringExtra("position")), job);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }


        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        BottomNavigationView.getMenu().findItem(R.id.navigation_home).setChecked(true);

    }

    public abstract class TweetAdapter extends RecyclerView.Adapter<TweetAdapter.ViewHolder> implements
            ViewPagerEx.OnPageChangeListener {
        ArrayList<JSONObject> data_list;
        Context context;


        public TweetAdapter(Context context, ArrayList<JSONObject> data_list) {
            this.context = context;
            this.data_list = data_list;
        }

        @Override
        public TweetAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_show_tweet, parent, false);
            return new TweetAdapter.ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final TweetAdapter.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
            try {
                holder.img_like.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {


                        try {
                            str_id_post_like = data_list.get(position).getString("id_post");
                            if (data_list.get(position).getString("is_like_post").equals("0")) {
                                // you going to like post
                                String a = new send_like().execute().get();
                                Log.e("post like", a);
                                holder.img_like.setImageDrawable(getResources().getDrawable(R.drawable.ic_action_heart));
                                holder.tv_number_like_profile.setText(String.valueOf(data_list.get(position).getInt("like_number") + 1));
                                data_list.get(position).put("is_like_post", "1");
                                data_list.get(position).put("like_number", holder.tv_number_like_profile.getText().toString());
                            } else {
                                String a = new send_like().execute().get();
                                Log.e("post like", a);
                                holder.img_like.setImageDrawable(getResources().getDrawable(R.drawable.ic_action_empty_heart));
                                holder.tv_number_like_profile.setText(String.valueOf(data_list.get(position).getInt("like_number") - 1));
                                data_list.get(position).put("is_like_post", "0");
                                data_list.get(position).put("like_number", holder.tv_number_like_profile.getText().toString());


                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        } catch (ExecutionException e) {
                            e.printStackTrace();
                        }
                    }
                });
                if (data_list.get(position).getString("repost_id").equals("0")) {
                    holder.tv_reweeted.setVisibility(View.GONE);
                } else {
                    holder.tv_reweeted.setVisibility(View.VISIBLE);
                    holder.tv_reweeted.setText("ریتویت شده از " + data_list.get(position).getString("user_name_repost"));
                }
                if (data_list.get(position).getString("is_like_post").equals("1")) {
                    holder.img_like.setImageDrawable(getResources().getDrawable(R.drawable.ic_action_heart));
                } else {
                    holder.img_like.setImageDrawable(getResources().getDrawable(R.drawable.ic_action_empty_heart));
                }
                JSONObject job_user = new JSONObject(data_list.get(position).getString("user"));
                holder.tv_profile_name_fragment.setText(job_user.getString("name"));

                holder.tv_profile_user_name_fragment.setText(job_user.getString("username"));
                if (!job_user.getString("image").equals("")) {
                    Picasso.with(context).load("http://meydane-azadi.ir/photo/photo.php?image_name=" + job_user.getString("image")).resize(512, 512).into(holder.image_profile_image_fragment);
                } else {
                    holder.image_profile_image_fragment.setImageResource(R.drawable.icon_user);
                }


                holder.tv_time_and_date_fragment.setText(data_list.get(position).getString("time"));
                holder.tv_text_profile_fragment.setText(data_list.get(position).getString("text"));
//                String a="";
//                a.indexOf("@");

                // tv.setText(text);
//                String content = text_tweet.substring(text_tweet.indexOf('@') + 1);
//                content=content.substring(0, content.indexOf(' '));
//                Toast.makeText(context, nickname[1]+"___"+ nickname.length+content, Toast.LENGTH_SHORT).show();
//
//                ClickableSpan clickableSpan = new ClickableSpan() {
//                    @Override
//                    public void onClick(View textView) {
//                     //   startActivity(new Intent(AllTweetActivity.this, NextActivity.class));
//                        Toast.makeText(context, "hiiii", Toast.LENGTH_SHORT).show();
//                    }
//
//                    @Override
//                    public void updateDrawState(TextPaint ds) {
//                        super.updateDrawState(ds);
//                        ds.setUnderlineText(false);
//                       // Toast.makeText(context, "bnyyyyy", Toast.LENGTH_SHORT).show();
//                    }
//                };
//                ss.setSpan(clickableSpan, text_tweet.indexOf(content)-1, text_tweet.indexOf(content)+content.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

                //holder.tv_text_profile_fragment.setText(text_tweet);
                holder.tv_text_profile_fragment.setMovementMethod(LinkMovementMethod.getInstance());
                holder.tv_text_profile_fragment.setHighlightColor(Color.TRANSPARENT);


                holder.tv_number_like_profile.setText(data_list.get(position).getString("like_number"));
                holder.tv_number_comment_profile.setText(data_list.get(position).getString("coment_number"));
                holder.tv_number_retweet_profile.setText(data_list.get(position).getString("repost_number"));


            } catch (JSONException e) {
                e.printStackTrace();
            }


            ArrayList<String> listUrl = new ArrayList<>();
            ArrayList<String> listName = new ArrayList<>();
            try {
                JSONArray jarr_image = data_list.get(position).getJSONArray("media");
                if (jarr_image.length() == 0) {
                    holder.mDemoSlider.setVisibility(View.GONE);
                } else {
                    holder.mDemoSlider.setVisibility(View.VISIBLE);
                }
                for (int i = 0; i < jarr_image.length(); i++) {
                    listUrl.add(jarr_image.getJSONObject(i).getString("url"));
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }


            RequestOptions requestOptions = new RequestOptions();
            requestOptions.centerCrop();
            //.diskCacheStrategy(DiskCacheStrategy.NONE)
            //.placeholder(R.drawable.placeholder)
            //.error(R.drawable.placeholder);
            holder.mDemoSlider.removeAllSliders();
            for (int i = 0; i < listUrl.size(); i++) {
                //TextSliderView sliderView = new TextSliderView(AllTweetActivity.this);
                DefaultSliderView sliderView = new DefaultSliderView(AllTweetActivity.this);
                // if you want show image only / without description text use DefaultSliderView instead
                // initialize SliderLayout
                sliderView
                        .image(listUrl.get(i))
                        .setRequestOption(requestOptions)
                        .setProgressBarVisible(true)
                        .setOnSliderClickListener(new BaseSliderView.OnSliderClickListener() {
                            @Override
                            public void onSliderClick(BaseSliderView slider) {
                                Intent i = new Intent(context, ShowTweetActivity.class);
                                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                                i.putExtra("ad", data_list.get(position).toString());
                                i.putExtra("position", position + "");
                                startActivityForResult(i, RESULT_DATA_SHOW_CHANGE);
                            }
                        });

                //add your extra information
                sliderView.bundle(new Bundle());
                sliderView.getBundle().putString("extra", "");
                holder.mDemoSlider.addSlider(sliderView);
            }
            // set Slider Transition Animation
            // mDemoSlider.setPresetTransformer(SliderLayout.Transformer.Default);
            holder.mDemoSlider.setPresetTransformer(SliderLayout.Transformer.Accordion);
            holder.mDemoSlider.setPresetIndicator(SliderLayout.PresetIndicators.Center_Bottom);
            holder.mDemoSlider.setCustomAnimation(new DescriptionAnimation());
            holder.mDemoSlider.setDuration(4000);
            holder.mDemoSlider.addOnPageChangeListener(this);
            holder.mDemoSlider.stopCyclingWhenTouch(false);


            if (position >= getItemCount() - 1) {

                load_more();
            }


            holder.linear_card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.e("data general:", data_list.get(position).toString());

                    Intent i = new Intent(context, ShowTweetActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                    i.putExtra("ad", data_list.get(position).toString());
                    context.startActivity(i);


                }
            });
            holder.linear_retweet_profile.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    Intent i = new Intent(AllTweetActivity.this, SendNewTweetActivity.class);
//                    i.putExtra("retweet", data_list.get(position).toString());
//                    startActivity(i);
                    try {
                        if (!data_list.get(position).getJSONObject("user").getString("user_token").equals(settings.getString("token", ""))) {
                            dialog_retweet(position, data_list.get(position));
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
            holder.tv_reweeted.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        Intent i = new Intent(AllTweetActivity.this, ActiviteAndShowTweeetActivity.class);
                        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        i.putExtra("user_token", data_list.get(position).getString("token_repost"));
                        startActivity(i);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
            holder.linear_profile.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        //go to profile
                        if (data_list.get(position).getJSONObject("user").getString("user_token").equals(settings.getString("token", ""))) {
                            Intent i = new Intent(AllTweetActivity.this, ProfileAndShowToitActivity.class);
                            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(i);
                        } else {
                            Intent i = new Intent(AllTweetActivity.this, ActiviteAndShowTweeetActivity.class);
                            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            i.putExtra("ad", data_list.get(position).getString("user"));
                            i.putExtra("user_token", data_list.get(position).getJSONObject("user").getString("user_token"));
                            //image
                            holder.image_profile_image_fragment.buildDrawingCache();
                            Bitmap image = holder.image_profile_image_fragment.getDrawingCache();
                            Bundle extras = new Bundle();
                            extras.putParcelable("imagebitmap", image);
                            i.putExtras(extras);
                            startActivityForResult(i, RESULT_DATA_USER_CHANGE);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
            try {


                //String text_tweet = "سلام من @nima_heydari هستم و از @mehdi دعوت به همکاری می کنم";
                String text_tweet=data_list.get(position).getString("text");

                SpannableString ss = new SpannableString(text_tweet);
                final ArrayList<String> nickname = new ArrayList<>();
                if (text_tweet.indexOf("@") == -1) {

                    nickname.add(text_tweet);
                    return;

                } else {
                    // nickname = Arrays.asList(text_tweet.split("@"));
                    String[] temp = text_tweet.split("@");
                    for (int i = 1; i < temp.length; i++) {
                        Log.e("print data",temp[i]);
                        if (temp[i].indexOf(' ') != -1) {
                            nickname.add(temp[i].substring(0, temp[i].indexOf(' ')));
                        }else{
                            nickname.add(text_tweet.replace("@","").trim());
                            text_tweet=text_tweet+" ";
                        }

                    }


                }
                for (String str:nickname){
                    if (str.length()<3){
                        nickname.remove(str);
                    }
                }
                // if (nickname.size() > 1) {
//                    for (String temp : nickname) {
//
//                    }

                for (int i = 0; i < nickname.size(); i++) {
                    // if (i > 0) {
//                    if (nickname.get(i).indexOf(' ') != -1) {
//                        nickname.set(i, nickname.get(i).substring(0, nickname.get(i).indexOf(' ')));
//                    }
                    nickname.set(i, "@" + nickname.get(i)+" ");
                    final int finalI = i;
                    ClickableSpan clickableSpan = new ClickableSpan() {
                        @Override
                        public void onClick(View textView) {
                            //   startActivity(new Intent(AllTweetActivity.this, NextActivity.class));
                            TextView textView2 = new TextView(context);
                            if (textView instanceof TextView) {
                                textView2 = (TextView) textView;


                                //Do your stuff
                            }
                            Toast.makeText(context, textView2.getText().toString() + finalI, Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void updateDrawState(TextPaint ds) {
                            //super.updateDrawState(' ');
                            // ds.setUnderlineText(true);
                            ds.setColor(Color.BLUE);


                            // Toast.makeText(context, "bnyyyyy", Toast.LENGTH_SHORT).show();
                        }
                    };
                    ClickableSpan clickableSpan2 = new ClickableSpan() {
                        @Override
                        public void onClick(View textView2) {
                            //   startActivity(new Intent(AllTweetActivity.this, NextActivity.class));
                            TextView textView3 = new TextView(context);
                            if (textView2 instanceof TextView) {
                                textView3 = (TextView) textView2;


                                //Do your stuff
                            }
                            Toast.makeText(context, nickname.get(finalI) + finalI, Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void updateDrawState(TextPaint ds) {
                            //super.updateDrawState(' ');
                            // ds.setUnderlineText(true);

                            ds.setColor(Color.GREEN);


                            // Toast.makeText(context, "bnyyyyy", Toast.LENGTH_SHORT).show();
                        }
                    };
                    Log.e("nikname", nickname.get(i));
                    // ss.setSpan(clickableSpan, 0, text_tweet.length() - 3, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    int start = 0;
                    int end = 0;
                    end = text_tweet.indexOf(nickname.get(i));

                    if (end >0) {
                        end = end - 1;
                    }

                    if (i == 0) {
                        start = 0;

                    } else {
                        start = text_tweet.indexOf(nickname.get(i - 1)) + nickname.get(i - 1).length()-1;
                    }
                  //  ss.setSpan(clickableSpan2, text_tweet.indexOf(nickname.get(i)), text_tweet.indexOf(nickname.get(i)) + nickname.get(i).length()-1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    ss.setSpan(clickableSpan, start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    if (i == nickname.size() - 1) {
                        if (text_tweet.length() != text_tweet.indexOf(nickname.get(nickname.size() - 1)) + nickname.get(nickname.size() - 1).length()) {
                            int start2 = text_tweet.indexOf(nickname.get(nickname.size() - 1))+nickname.get(nickname.size()-1).length()-1;
                            int end2 = text_tweet.length();
                            ClickableSpan clickableSpan3 = new ClickableSpan() {
                                @Override
                                public void onClick(View textView) {
                                    //   startActivity(new Intent(AllTweetActivity.this, NextActivity.class));
                                    TextView textView2 = new TextView(context);
                                    if (textView instanceof TextView) {
                                        textView2 = (TextView) textView;
                                        //Do your stuff
                                    }
                                    Toast.makeText(context, textView2.getText().toString() + finalI, Toast.LENGTH_SHORT).show();
                                }

                                @Override
                                public void updateDrawState(TextPaint ds) {
                                    //super.updateDrawState(' ');
                                    // ds.setUnderlineText(true);
                                    ds.setColor(Color.BLUE);

                                }
                            };

                            ss.setSpan(clickableSpan3, start2, end2, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        }
                    }
                }

                //  }
                // }
                holder.tv_text_profile_fragment.setText(ss);
            }catch (Exception e){

                try {
                    holder.tv_text_profile_fragment.setText(data_list.get(position).getString("text"));
//                    Log.e("error",e.getMessage());
                    e.printStackTrace();
                } catch (JSONException ex) {
                    ex.printStackTrace();
                }
                holder.tv_text_profile_fragment.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(context, "felan", Toast.LENGTH_SHORT).show();
                    }
                });

            }


        }

        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(int position) {

        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }

        public abstract void load_more();


        @Override
        public int getItemCount() {
            return data_list.size();
        }

        public void insert(int position, JSONArray ad_list) {


            try {


                for (int i = 0; i < ad_list.length(); i++) {


                    data_list.add(ad_list.getJSONObject(i));
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
            notifyItemInserted(position);


        }


        public void clear_list() {

            int size = data_list.size();
            data_list.clear();
            notifyItemRangeRemoved(0, size);
        }

        public void update_item(int pos, JSONObject job) {
            data_list.set(pos, job);
            notifyItemChanged(pos);
        }


        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView tv_profile_name_fragment;
            TextView tv_profile_user_name_fragment;
            ImageView image_profile_image_fragment;
            TextView tv_time_and_date_fragment;
            TextView tv_text_profile_fragment;
            TextView tv_number_like_profile;
            TextView tv_number_comment_profile;
            TextView tv_number_retweet_profile;
            // SliderLayout slider_profile_fragment;
            ImageView img_like;
            ImageView img_comment;
            LinearLayout linear_card;
            LinearLayout linear_retweet_profile;
            SliderLayout mDemoSlider;
            TextView tv_reweeted;
            LinearLayout linear_profile;
            RelativeLayout relative_test;

            //  com.smarteist.autoimageslider.SliderLayout sliderLayout;


            public ViewHolder(View item) {
                super(item);
                tv_profile_name_fragment = (TextView) item.findViewById(R.id.tv_profile_name_fragment);
                tv_profile_user_name_fragment = (TextView) item.findViewById(R.id.tv_profile_user_name_fragment);
                //ad_location = (TextView) item.findViewById(R.id.ad_location);
                image_profile_image_fragment = (ImageView) item.findViewById(R.id.image_profile_image_fragment);
                tv_time_and_date_fragment = (TextView) item.findViewById(R.id.tv_time_and_date_fragment);
                tv_text_profile_fragment = (TextView) item.findViewById(R.id.tv_text_profile_fragment);
                // slider_profile_fragment = item.findViewById(R.id.slider_profile_fragment);
                tv_number_like_profile = item.findViewById(R.id.tv_number_like_profile);
                tv_number_comment_profile = item.findViewById(R.id.tv_number_comment_profile);
                tv_number_retweet_profile = item.findViewById(R.id.tv_number_retweet_profile);
                img_like = item.findViewById(R.id.img_like);
                img_comment = item.findViewById(R.id.img_comment);
                linear_card = item.findViewById(R.id.linear_card);
                mDemoSlider = item.findViewById(R.id.slider);
                linear_retweet_profile = item.findViewById(R.id.linear_retweet_profile);
                // sliderLayout=item.findViewById(R.id.imageSlider);
                tv_reweeted = item.findViewById(R.id.tv_reweeted);
                linear_profile = item.findViewById(R.id.linear_profile);
                relative_test = item.findViewById(R.id.relative_test);
            }
        }
    }

    public class get_list_tweet extends AsyncTask<String, Void, String> {
        ProgressDialog pd = new ProgressDialog(AllTweetActivity.this);

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            pd.setMessage("در حال دریافت اطلاعات");
            pd.setCancelable(false);
            progress_ball.setVisibility(View.VISIBLE);
            //pd.show();
        }

        @Override
        protected String doInBackground(final String... params) {
//            runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//
//
//                    Toast.makeText(AllTweetActivity.this, params[0].toString(), Toast.LENGTH_SHORT).show();
//                    // finish();
//
//                }
//            });
            ArrayList<NameValuePair> namevaluepairs = new ArrayList<NameValuePair>();
            final JSONObject get_ad_list = new JSONObject();
            mcrypt = new MainActivity.MCrypt();
            try {

                get_ad_list.put("command", mcrypt.bytesToHex(mcrypt.encrypt("post_read_home")));
                get_ad_list.put("last_ad_id", mcrypt.bytesToHex(mcrypt.encrypt(String.valueOf(last_ad_id))));
                get_ad_list.put("token", mcrypt.bytesToHex(mcrypt.encrypt(settings.getString("token", ""))));

                get_ad_list.put("user_id", mcrypt.bytesToHex(mcrypt.encrypt(String.valueOf(settings.getInt("user_id", 0)))));
                get_ad_list.put("search", mcrypt.bytesToHex(mcrypt.encrypt("")));

                // get_ad_list.put("text",mcrypt.bytesToHex(mcrypt.encrypt(Base64.encodeToString(search_key.getBytes("UTF-8"), Base64.DEFAULT))));


            } catch (JSONException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }


            namevaluepairs.add(new BasicNameValuePair("myjson", get_ad_list.toString()));
            Log.e("data sended", get_ad_list.toString());

            try {

                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost("http://meydane-azadi.ir/api/mwwap/ecxa.php");
                httppost.setEntity(new UrlEncodedFormEntity(namevaluepairs, HTTP.UTF_8));

                HttpResponse httpresponse = httpclient.execute(httppost);

                String response = EntityUtils.toString(httpresponse.getEntity());

                Log.e("data respose", response);

                if (response.startsWith("<azadi>") && response.endsWith("</azadi>")) {//response is valid

                    response = response.replace("<azadi>", "").replace("</azadi>", "");
                    // response = new String(mcrypt.decrypt(response)).trim();


                    final String finalResponse = response;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            try {
                                ad_list = new JSONArray(finalResponse);
                                not_found.setVisibility(View.GONE);

                                if (ad_list.length() == 0 & last_ad_id == 0) {

                                    not_found.setVisibility(View.VISIBLE);

                                }

                                if (ad_list.length() != 0) {

                                    last_ad_id = ad_list.getJSONObject(ad_list.length() - 1).getInt("id");


                                    if (ad_list.length() != 10) {
                                        last_ad_id = -1;
                                    }


                                } else {

                                    last_ad_id = -1;
                                }


                                adapter.insert(adapter.getItemCount(), ad_list);

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    });

                } else {


                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {


                            Toast.makeText(AllTweetActivity.this, "خطا در دریافت اطلاعات", Toast.LENGTH_SHORT).show();
                            // finish();

                        }
                    });


                }

                return response;
            } catch (Exception e) {
                e.printStackTrace();

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {


                        Toast.makeText(AllTweetActivity.this, "خطا در دریافت اطلاعات", Toast.LENGTH_SHORT).show();
                        //finish();
                    }
                });
                return null;
            }

        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
//            pd.hide();
//            pd.dismiss();
            progress_ball.setVisibility(View.GONE);
        }
    }


    public class send_like extends AsyncTask<String, Void, String> {
        ProgressDialog pd = new ProgressDialog(AllTweetActivity.this);

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            //   pd.setMessage("در حال دریافت اطلاعات");
            //  pd.setCancelable(false);
            //   pd.show();
        }

        @Override
        protected String doInBackground(String... params) {

            ArrayList<NameValuePair> namevaluepairs = new ArrayList<NameValuePair>();
            final JSONObject get_ad_list = new JSONObject();
            mcrypt = new MainActivity.MCrypt();
            try {

                get_ad_list.put("command", mcrypt.bytesToHex(mcrypt.encrypt("insert_like_post")));
                get_ad_list.put("token", mcrypt.bytesToHex(mcrypt.encrypt(settings.getString("token", ""))));
                get_ad_list.put("post_id", mcrypt.bytesToHex(mcrypt.encrypt(str_id_post_like)));
                get_ad_list.put("android_id", mcrypt.bytesToHex(mcrypt.encrypt(str_android_id)));


                // get_ad_list.put("text",mcrypt.bytesToHex(mcrypt.encrypt(Base64.encodeToString(search_key.getBytes("UTF-8"), Base64.DEFAULT))));


            } catch (JSONException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }


            namevaluepairs.add(new BasicNameValuePair("myjson", get_ad_list.toString()));
            Log.e("data sended", get_ad_list.toString());

            try {

                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost("http://meydane-azadi.ir/api/mwwap/ecxa.php");
                httppost.setEntity(new UrlEncodedFormEntity(namevaluepairs, HTTP.UTF_8));

                HttpResponse httpresponse = httpclient.execute(httppost);

                String response = EntityUtils.toString(httpresponse.getEntity());

                Log.e("data respose", response);
                if (response.startsWith("<azadi>") && response.endsWith("</azadi>")) {//response is valid

                    response = response.replace("<azadi>", "").replace("</azadi>", "");
                    // response = new String(mcrypt.decrypt(response)).trim();


                    final String finalResponse = response;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {


                        }
                    });

                } else {


                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {


                            Toast.makeText(AllTweetActivity.this, "خطا در دریافت اطلاعات", Toast.LENGTH_SHORT).show();
                            // finish();

                        }
                    });


                }

                return response;
            } catch (Exception e) {
                e.printStackTrace();

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {


                        Toast.makeText(AllTweetActivity.this, "خطا در دریافت اطلاعات", Toast.LENGTH_SHORT).show();
                        //finish();
                    }
                });
                return null;
            }

        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
//            pd.hide();
//            pd.dismiss();

        }
    }


}
