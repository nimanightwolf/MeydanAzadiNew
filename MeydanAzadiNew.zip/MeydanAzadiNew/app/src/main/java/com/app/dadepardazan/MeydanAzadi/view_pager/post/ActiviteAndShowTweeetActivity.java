package com.app.dadepardazan.MeydanAzadi.view_pager.post;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.ToxicBakery.viewpager.transforms.RotateUpTransformer;
import com.app.dadepardazan.MeydanAzadi.MainActivity;
import com.app.dadepardazan.MeydanAzadi.R;
import com.google.android.material.tabs.TabLayout;
import com.squareup.picasso.Picasso;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class ActiviteAndShowTweeetActivity extends MainActivity {
    ViewPagerAdapter view_pagerAdapter;
    TabLayout mtabTabLayout;
    SharedPreferences settings;
    TextView toolbar_title;
    TextView tv_profile_name;
    TextView tv_profile_bio;
    TextView tv_profile_user_name;
    TextView tv_profile_followers;
    TextView tv_profile_following;
    CircleImageView profile_image;
    CardView card_btn_profile_followering;
    TextView tv_profile_followering;
    CardView card_btn_profile_kasb_dar_amadm;
    private MCrypt mcrypt;
    ArrayList<ImageView> images = new ArrayList<ImageView>();
    int current_image;
    String string_id = "";
    JSONObject job_gereral;
    String str_android_id="";
    String str_user_token="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout content_frame;

        content_frame = (FrameLayout) findViewById(R.id.content_frame);
        getLayoutInflater().inflate(R.layout.activity_activite_and_show_tweeet, content_frame);
        toolbar_title = (TextView) findViewById(R.id.toolbar_title);
        toolbar_title.setText("میدان آزادی");
        toolbar_title.setTextSize(24);
        toolbar_title.setVisibility(View.VISIBLE);

        str_android_id = Settings.Secure.getString(this.getContentResolver(), Settings.Secure.ANDROID_ID);


        findviewbyid();

        try {
          //  Log.e("data intent", getIntent().getStringExtra("ad"));
            str_user_token=getIntent().getStringExtra("user_token");
            if (getIntent().hasExtra("ad") ){
                job_gereral = new JSONObject(getIntent().getStringExtra("ad"));
                setVlaueFromJson();
                Bundle extras = getIntent().getExtras();
                Bitmap bmp = (Bitmap) extras.getParcelable("imagebitmap");
                profile_image.setImageBitmap(bmp);
            }
            else{
                new get_user_info().execute();
            }

            // tv_profile_name.setText(job_gereral.getString("name"));




        } catch (JSONException e) {
            e.printStackTrace();
        }
        card_btn_profile_followering.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (job_gereral.getString("is_follow").equals("1")) {
                        tv_profile_followering.setText("دنبال کرده اید");
                        card_btn_profile_followering.setBackgroundColor(getResources().getColor(R.color.color_followed));
                        job_gereral.put("is_follow", "0");
                        card_btn_profile_followering.setRadius(8);
                        new send_follow().execute();
                    } else {
                        tv_profile_followering.setText("دنبال کنید");
                        card_btn_profile_followering.setBackgroundColor(getResources().getColor(R.color.color_following));
                        job_gereral.put("is_follow", "1");
                        card_btn_profile_followering.setRadius(8);
                        new send_follow().execute();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });


        ViewPager vpPager = (ViewPager) findViewById(R.id.vpPager_profile);
        mtabTabLayout = (TabLayout) findViewById(R.id.tablayout_profile);
        mtabTabLayout.setupWithViewPager(vpPager);


        // mtabTabLayout.setTabTextColors(ColorStateList.valueOf(Color.parseColor("#00000")));
        //mtabTabLayout.setTabTextColors(getResources().getColor(R.color.color_hint_white), getResources().getColor(R.color.colorblack));
//
        view_pagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        vpPager.setAdapter(view_pagerAdapter);
        vpPager.setPageTransformer(true, new RotateUpTransformer());
        if (vpPager.getCurrentItem() == 0) {
            //     navigationView.getMenu().findItem(R.id.mnu_category).setChecked(true);
        } else if (vpPager.getCurrentItem() == 1) {
            //    navigationView.getMenu().findItem(R.id.mnu_category).setChecked(true);
        }

        //برای تغییر صفحه با کد
        vpPager.setCurrentItem(2);
        settings = PreferenceManager.getDefaultSharedPreferences(this);
//        if (settings.getInt("theme", 0) == 1) {
//            //setTheme(R.style.NoActionBarDark);
//            mtabTabLayout.setBackgroundColor(Color.parseColor("#4C4C4C"));
//           // mtabTabLayout.setTabTextColors(ColorStateList.valueOf(Color.parseColor("#00000")));
//            mtabTabLayout.setTabTextColors(getResources().getColor(R.color.colorwhite), getResources().getColor(R.color.colorwhite));
//
//
//        }
//        if (settings.getInt("theme", 0) == 2) {
//            //setTheme(R.style.NoActionBarBlack);
//            mtabTabLayout.setBackgroundColor(Color.parseColor("#000000"));
//        }

        //new get_list_search().execute();

    }

    private void setVlaueFromJson() {
        try {
            tv_profile_name.setText(job_gereral.getJSONObject("user").getString("name"));
            tv_profile_user_name.setText(job_gereral.getJSONObject("user").getString("username"));
            tv_profile_bio.setText(job_gereral.getJSONObject("user").getString("bio"));
            tv_profile_followers.setText(job_gereral.getJSONObject("user").getString("followers") + "\n دنبال کننده ها");
            tv_profile_following.setText(job_gereral.getJSONObject("user").getString("following") + "\n دنبال شونده ها");
            if (job_gereral.getJSONObject("user").getString("is_follow").equals("1")) {
                tv_profile_followering.setText("دنبال کنید");
                card_btn_profile_followering.setBackgroundColor(getResources().getColor(R.color.color_following));
                card_btn_profile_followering.setRadius(8);

            } else {
                tv_profile_followering.setText("دنبال کرده اید");
                card_btn_profile_followering.setBackgroundColor(getResources().getColor(R.color.color_followed));
                card_btn_profile_followering.setRadius(8);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void findviewbyid() {

        tv_profile_name = findViewById(R.id.tv_profile_name);
        tv_profile_bio = findViewById(R.id.tv_profile_bio);
        tv_profile_user_name = findViewById(R.id.tv_profile_user_name);
        profile_image = findViewById(R.id.profile_image);
        card_btn_profile_followering = findViewById(R.id.card_btn_profile_followering);
        card_btn_profile_kasb_dar_amadm = findViewById(R.id.card_btn_profile_kasb_dar_amadm);
        //card_btn_profile_kasb_dar_amadm.setVisibility(View.GONE);
        card_btn_profile_followering.setVisibility(View.VISIBLE);

        tv_profile_followers = findViewById(R.id.tv_profile_followers);
        tv_profile_following = findViewById(R.id.tv_profile_following);
        tv_profile_followering = findViewById(R.id.tv_profile_followering);


    }

    public class ViewPagerAdapter extends FragmentPagerAdapter {
        private int NUM_ITEMS = 1;

        public ViewPagerAdapter(FragmentManager fragmentManager) {

            super(fragmentManager);

        }

        // Returns total number of pages.

        @Override

        public int getCount() {

            return NUM_ITEMS;

        }

        // Returns the fragment to display for a particular page.

        @Override

        public Fragment getItem(int position) {

            switch (position) {

                case 0:

                    return FragmentTweet.newInstance("toit", str_user_token);

                case 1:

                    return FragmentActivite.newInstance("activites", job_gereral.toString());
                default:

                    return null;

            }

        }

        // Returns the page title for the top indicator

        @Override

        public CharSequence getPageTitle(int position) {

            if (position == 0)
                return "توییت ها";
            if (position == 1)
                return "فعالیت ها";
            else
                return "";


        }
    }
    public class get_user_info extends AsyncTask<Void, Void, String> {
        ProgressDialog pd = new ProgressDialog(ActiviteAndShowTweeetActivity.this);

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            pd.setMessage("در حال دریافت اطلاعات");
            pd.setCancelable(false);
            //    pd.show();
            progress_ball.setVisibility(View.VISIBLE);
            progress_ball.show();
        }

        @Override
        protected String doInBackground(Void... params) {

            ArrayList<NameValuePair> namevaluepairs = new ArrayList<NameValuePair>();
            final JSONObject get_ad_list = new JSONObject();
            mcrypt = new MainActivity.MCrypt();
            try {

                get_ad_list.put("command", mcrypt.bytesToHex(mcrypt.encrypt("get_user_info")));
                get_ad_list.put("user_id", mcrypt.bytesToHex(mcrypt.encrypt(String.valueOf(settings.getInt("user_id", 0)))));
                get_ad_list.put("token", mcrypt.bytesToHex(mcrypt.encrypt(str_user_token)));
                get_ad_list.put("android_id", mcrypt.bytesToHex(mcrypt.encrypt(str_android_id)));


            } catch (JSONException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }


            namevaluepairs.add(new BasicNameValuePair("myjson", get_ad_list.toString()));
            Log.e("data sended", get_ad_list.toString());

            try {

                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost("http://meydane-azadi.ir/api/mwwap/ecxa.php");
                httppost.setEntity(new UrlEncodedFormEntity(namevaluepairs, HTTP.UTF_8));

                HttpResponse httpresponse = httpclient.execute(httppost);

                String response = EntityUtils.toString(httpresponse.getEntity());


                if (response.startsWith("<azadi>") && response.endsWith("</azadi>")) {//response is valid

                    response = response.replace("<azadi>", "").replace("</azadi>", "");
                    response = new String(mcrypt.decrypt(response)).trim();
                    Log.e("data respose", response);


                    final String finalResponse = response;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                job_gereral=new JSONObject(finalResponse);
                                setVlaueFromJson();
                                if (!job_gereral.getString("image_address").equals("")) {
                                    Picasso.with(ActiviteAndShowTweeetActivity.this).load(job_gereral.getString("image_address")).resize(512, 512).into(profile_image);
                                } else {
                                    profile_image.setImageResource(R.drawable.icon_user);

                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    });

                } else {


                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {


                            Toast.makeText(ActiviteAndShowTweeetActivity.this, "خطا در دریافت اطلاعات", Toast.LENGTH_SHORT).show();
                            finish();

                        }
                    });


                }


            } catch (Exception e) {
                e.printStackTrace();

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {


                        Toast.makeText(ActiviteAndShowTweeetActivity.this, "خطا در دریافت اطلاعات", Toast.LENGTH_SHORT).show();
                        finish();

                    }
                });


            }


            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
//            pd.hide();
////            pd.dismiss();
            progress_ball.setVisibility(View.GONE);
        }
    }

    public class send_follow extends AsyncTask<Void, Void, String> {
        ProgressDialog pd = new ProgressDialog(ActiviteAndShowTweeetActivity.this);

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            pd.setMessage("در حال دریافت اطلاعات");
            pd.setCancelable(false);
            //    pd.show();
            progress_ball.setVisibility(View.VISIBLE);
            progress_ball.show();
        }

        @Override
        protected String doInBackground(Void... params) {

            ArrayList<NameValuePair> namevaluepairs = new ArrayList<NameValuePair>();
            final JSONObject get_ad_list = new JSONObject();
            mcrypt = new MainActivity.MCrypt();
            try {

                get_ad_list.put("command", mcrypt.bytesToHex(mcrypt.encrypt("follow_user")));
                get_ad_list.put("user_id", mcrypt.bytesToHex(mcrypt.encrypt(String.valueOf(settings.getInt("user_id", 0)))));
                get_ad_list.put("token", mcrypt.bytesToHex(mcrypt.encrypt(str_user_token)));


            } catch (JSONException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }


            namevaluepairs.add(new BasicNameValuePair("myjson", get_ad_list.toString()));
            Log.e("data sended", get_ad_list.toString());

            try {

                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost("http://meydane-azadi.ir/api/mwwap/ecxa.php");
                httppost.setEntity(new UrlEncodedFormEntity(namevaluepairs, HTTP.UTF_8));

                HttpResponse httpresponse = httpclient.execute(httppost);

                String response = EntityUtils.toString(httpresponse.getEntity());


                if (response.startsWith("<azadi>") && response.endsWith("</azadi>")) {//response is valid

                    response = response.replace("<azadi>", "").replace("</azadi>", "");
                    response = new String(mcrypt.decrypt(response)).trim();
                    response= response.replace("\"","");

                    Log.e("data respose", response);

                    final String finalResponse = response;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (finalResponse.equals("follow")) {
                                tv_profile_followering.setText("دنبال کرده اید");
                                card_btn_profile_followering.setBackgroundColor(getResources().getColor(R.color.color_followed));

                            } else {
                                tv_profile_followering.setText("دنبال کنید");
                                card_btn_profile_followering.setBackgroundColor(getResources().getColor(R.color.color_following));

                            }
                            setResult(RESULT_OK);

                        }
                    });

                } else {


                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {


                            Toast.makeText(ActiviteAndShowTweeetActivity.this, "خطا در دریافت اطلاعات", Toast.LENGTH_SHORT).show();
                            finish();

                        }
                    });


                }


            } catch (Exception e) {
                e.printStackTrace();

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {


                        Toast.makeText(ActiviteAndShowTweeetActivity.this, "خطا در دریافت اطلاعات", Toast.LENGTH_SHORT).show();
                        finish();

                    }
                });


            }


            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
//            pd.hide();
////            pd.dismiss();
            progress_ball.setVisibility(View.GONE);
        }
    }


}