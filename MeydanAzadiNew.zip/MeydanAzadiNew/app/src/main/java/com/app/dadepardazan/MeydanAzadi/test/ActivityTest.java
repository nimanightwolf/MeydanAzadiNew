package com.app.dadepardazan.MeydanAzadi.test;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.app.dadepardazan.MeydanAzadi.R;

/**
 * Created by Bamdad on 4/16/2020.
 */

public class ActivityTest extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_user);


    }

}
