package com.app.dadepardazan.MeydanAzadi.view_pager.post;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.SpannableString;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.app.dadepardazan.MeydanAzadi.MainActivity;
import com.app.dadepardazan.MeydanAzadi.R;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class FragmentActivite extends Fragment {

    private String title;
    private JSONObject job_data;
    SharedPreferences settings;
    RecyclerView recyclerview;
    ActiviteFragmentAdapter adapter;
    MainActivity.MCrypt mcrypt;
    JSONObject ad = new JSONObject();
    private int last_ad_id = 0;
    boolean is_like = false;

    public static FragmentActivite newInstance(String title, String data) {

        FragmentActivite fragment = new FragmentActivite();

        Bundle args = new Bundle();

        args.putString("data", data);

        args.putString("title", title);

        fragment.setArguments(args);

        return fragment;

    }

    @Override

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        try {
            job_data = new JSONObject(getArguments().getString("data"));
            //Toast.makeText(getActivity(), job_data.toString(), Toast.LENGTH_SHORT).show();

            title = getArguments().getString("title");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        //getActivity().setTheme(R.style.NoActionBarDark);

        View view_main = inflater.inflate(R.layout.fragmant_search, container, false);
        settings = PreferenceManager.getDefaultSharedPreferences(getActivity());


        recyclerview = view_main.findViewById(R.id.recyclerview_fragmant_search);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerview.setLayoutManager(layoutManager);

        final ArrayList<JSONObject> data_list = new ArrayList<JSONObject>();
        for (int i = 0; i < 4; i++) {
            JSONObject a = new JSONObject();
            data_list.add(a);
        }
        adapter = new ActiviteFragmentAdapter(getContext(), data_list) {
            @Override
            public void load_more() {

            }
        };
        recyclerview.setAdapter(adapter);


        setHasOptionsMenu(true);
        return view_main;

    }


    @Override
    public void onResume() {
        super.onResume();
        // Toast.makeText(getContext(),"2222",Toast.LENGTH_SHORT).show();
//        last_ad_id = 0;
//        adapter.clear_list();
//        new get_my_ad_list().execute();
//        new get_add().execute();
    }


    public abstract class ActiviteFragmentAdapter extends RecyclerView.Adapter<ActiviteFragmentAdapter.ViewHolder> {
        ArrayList<JSONObject> data_list;
        Context context;


        public ActiviteFragmentAdapter(Context context, ArrayList<JSONObject> data_list) {
            this.context = context;
            this.data_list = data_list;
        }

        @Override
        public ActiviteFragmentAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_activite, parent, false);
            return new ActiviteFragmentAdapter.ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final ActiviteFragmentAdapter.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {

            String normalBOLD=  "نیما حیدری ";
            String normalBefore = "کامنتی برای شما گذاشت";
            String normalAfter= "5d";
            String finalString= normalBOLD+normalBefore+normalAfter;
            SpannableString sb = new SpannableString( finalString );
            sb.setSpan(new StyleSpan(android.graphics.Typeface.BOLD), 0, normalBOLD.length(),0); //bold
            sb.setSpan(new AbsoluteSizeSpan(18), normalBOLD.length()+ normalBefore.length(), finalString.length(),0);//resize size


//            String s= "Hello Everyone";
//            Spanned str_name2;
//            SpannableString str_name=  new SpannableString(s);
//            str_name2=(Html.fromHtml( "نیما حیدری"  +
//                    "<small>" + "برای شما کامنتی گذاشته است. کاملا درست است" + "</small>" +
//                    "<small>" + "5d" + "</small>"));
//            str_name.setSpan(new StyleSpan(android.graphics.Typeface.BOLD), 0,normalBefore.length(), 0); // set size
//
//            str_name.setSpan(new ForegroundColorSpan(Color.RED), 0, 5, 0);// set color
            holder.tv_activite.setText( sb);


            if (position >= getItemCount() - 1) {

                load_more();
            }


//            holder.linear_card.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    Log.e("data general:", data_list.get(position).toString());
//
//                    Intent i = new Intent(context, ShowTweetActivity.class);
//                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                    i.putExtra("ad", data_list.get(position).toString());
//                    context.startActivity(i);
//
//
//                }
//            });
        }



        public abstract void load_more();


        @Override
        public int getItemCount() {
            return data_list.size();
        }

        public void insert(int position, JSONArray ad_list) {


            try {

                for (int i = 0; i < ad_list.length(); i++) {


                    data_list.add(ad_list.getJSONObject(i));
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
            notifyItemInserted(position);


        }


        public void clear_list() {

            int size = data_list.size();
            data_list.clear();
            notifyItemRangeRemoved(0, size);
        }


        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView tv_activite;
            LinearLayout item_layout;
            CardView cardv;

            public ViewHolder(View item) {
                super(item);
                tv_activite = (TextView) item.findViewById(R.id.tv_activite);
                item_layout = item.findViewById(R.id.item_layout);
                cardv=item.findViewById(R.id.cardv);


            }
        }
    }

    public class get_list_tweet extends AsyncTask<Void, Void, String> {
        ProgressDialog pd = new ProgressDialog(getActivity());

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            pd.setMessage("در حال دریافت اطلاعات");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(Void... params) {

            ArrayList<NameValuePair> namevaluepairs = new ArrayList<NameValuePair>();
            final JSONObject get_ad_list = new JSONObject();
            mcrypt = new MainActivity.MCrypt();
            try {

                get_ad_list.put("command", mcrypt.bytesToHex(mcrypt.encrypt("search_in")));
                //get_coment_list.put("category_filter", settings.getInt("category_filter", 0));
                get_ad_list.put("user_id", mcrypt.bytesToHex(mcrypt.encrypt(String.valueOf(settings.getInt("user_id", 0)))));
                get_ad_list.put("type", mcrypt.bytesToHex(mcrypt.encrypt("1")));
                // get_ad_list.put("text",mcrypt.bytesToHex(mcrypt.encrypt(Base64.encodeToString(search_key.getBytes("UTF-8"), Base64.DEFAULT))));


            } catch (JSONException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }


            namevaluepairs.add(new BasicNameValuePair("myjson", get_ad_list.toString()));
            Log.e("data sended", get_ad_list.toString());

            try {

                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost("http://meydane-azadi.ir/api/mwwap/ecxa.php");
                httppost.setEntity(new UrlEncodedFormEntity(namevaluepairs, HTTP.UTF_8));

                HttpResponse httpresponse = httpclient.execute(httppost);

                String response = EntityUtils.toString(httpresponse.getEntity());


                if (response.startsWith("<azadi>") && response.endsWith("</azadi>")) {//response is valid

                    response = response.replace("<azadi>", "").replace("</azadi>", "");
                    response = new String(mcrypt.decrypt(response)).trim();
                    Log.e("data respose", response);


                    final String finalResponse = response;
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            try {
                                JSONArray ad_list = new JSONArray(finalResponse);
                                //not_found.setVisibility(View.GONE);

                                if (ad_list.length() == 0 && last_ad_id == 0) {

                                    // not_found.setVisibility(View.VISIBLE);

                                }

                                if (ad_list.length() != 0) {

                                    last_ad_id = ad_list.getJSONObject(ad_list.length() - 1).getInt("id");


                                    if (ad_list.length() != 10) {
                                        //  last_ad_id = -1;
                                    }


                                } else {

                                    // last_ad_id = -1;
                                }


                                adapter.insert(adapter.getItemCount(), ad_list);

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    });

                } else {


                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {


                            Toast.makeText(getActivity(), "خطا در دریافت اطلاعات", Toast.LENGTH_SHORT).show();
                            getActivity().finish();

                        }
                    });


                }


            } catch (Exception e) {
                e.printStackTrace();

                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {


                        Toast.makeText(getActivity(), "خطا در دریافت اطلاعات", Toast.LENGTH_SHORT).show();
                        getActivity().finish();
                    }
                });
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
        }
    }

    public class send_like extends AsyncTask<Void, Void, String> {
        ProgressDialog pd = new ProgressDialog(getActivity());

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            pd.setMessage("در حال دریافت اطلاعات");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(Void... params) {

            ArrayList<NameValuePair> namevaluepairs = new ArrayList<NameValuePair>();
            final JSONObject get_ad_list = new JSONObject();
            mcrypt = new MainActivity.MCrypt();
            try {

                get_ad_list.put("command", mcrypt.bytesToHex(mcrypt.encrypt("search_in")));
                //get_coment_list.put("category_filter", settings.getInt("category_filter", 0));
                get_ad_list.put("user_id", mcrypt.bytesToHex(mcrypt.encrypt(String.valueOf(settings.getInt("user_id", 0)))));
                get_ad_list.put("type", mcrypt.bytesToHex(mcrypt.encrypt("1")));
                // get_ad_list.put("text",mcrypt.bytesToHex(mcrypt.encrypt(Base64.encodeToString(search_key.getBytes("UTF-8"), Base64.DEFAULT))));


            } catch (JSONException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }


            namevaluepairs.add(new BasicNameValuePair("myjson", get_ad_list.toString()));
            Log.e("data sended", get_ad_list.toString());

            try {

                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost("http://meydane-azadi.ir/api/mwwap/ecxa.php");
                httppost.setEntity(new UrlEncodedFormEntity(namevaluepairs, HTTP.UTF_8));
                HttpResponse httpresponse = httpclient.execute(httppost);
                String response = EntityUtils.toString(httpresponse.getEntity());

                if (response.startsWith("<azadi>") && response.endsWith("</azadi>")) {//response is valid

                    response = response.replace("<azadi>", "").replace("</azadi>", "");
                    response = new String(mcrypt.decrypt(response)).trim();
                    Log.e("data respose", response);


                    final String finalResponse = response;

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            try {
                                JSONArray ad_list = new JSONArray(finalResponse);
                                //not_found.setVisibility(View.GONE);

                                if (ad_list.length() == 0 && last_ad_id == 0) {

                                    // not_found.setVisibility(View.VISIBLE);

                                }

                                if (ad_list.length() != 0) {

                                    last_ad_id = ad_list.getJSONObject(ad_list.length() - 1).getInt("id");


                                    if (ad_list.length() != 10) {
                                        //  last_ad_id = -1;
                                    }


                                } else {

                                    // last_ad_id = -1;
                                }


                                adapter.insert(adapter.getItemCount(), ad_list);

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    });

                } else {


                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {


                            Toast.makeText(getActivity(), "خطا در دریافت اطلاعات", Toast.LENGTH_SHORT).show();
                            getActivity().finish();

                        }
                    });


                }


            } catch (Exception e) {
                e.printStackTrace();

                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {


                        Toast.makeText(getActivity(), "خطا در دریافت اطلاعات", Toast.LENGTH_SHORT).show();
                        getActivity().finish();
                    }
                });
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
        }
    }


}