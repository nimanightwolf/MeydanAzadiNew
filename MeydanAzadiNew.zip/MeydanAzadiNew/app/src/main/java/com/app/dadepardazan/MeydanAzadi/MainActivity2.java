package com.app.dadepardazan.MeydanAzadi;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Created by Bamdad on 1/29/2019.
 */

public class MainActivity2 extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
       // toolbar.setVisibility(View.GONE);

    }
}
